# -*- coding: utf-8 -*-
from __future__ import absolute_import, print_function, unicode_literals
from Plugins.Plugin import PluginDescriptor
from Screens.Screen import Screen
from Components.ActionMap import ActionMap
from Components.Label import Label
from Components.config import config, ConfigSubsection, ConfigText, ConfigSelection
from Screens.MessageBox import MessageBox
import subprocess
import re
import os
from enigma import gRGB, eTimer
from twisted.web.client import getPage

# ---
# القسم 1: تعريف الثوابت والإعدادات
# ---

# تعريف إعدادات البلجن
config.plugins.TVSATMAROC = ConfigSubsection()
config.plugins.TVSATMAROC.username = ConfigText(default="", fixed_size=False)
config.plugins.TVSATMAROC.password = ConfigText(default="", fixed_size=False)
config.plugins.TVSATMAROC.protocol = ConfigSelection(default="cccam", choices=[("cccam", "CCCam"), ("newcamd", "Newcamd")])
config.plugins.TVSATMAROC.destination = ConfigSelection(default="oscam", choices=[("oscam", "OSCam"), ("ncam", "NCam")])

# تعريف مسارات الملفات ومعلومات السيرفر الثابتة
OSCAM_PATH = "/etc/tuxbox/config/oscam.server"
NCAM_PATH = "/etc/tuxbox/config/ncam.server"
INSTALLER_PATH = "/tmp/installer.sh" # مسار مؤقت لتنزيل سكربت التثبيت

CC_HOST = "tvsatmaroc.online"
CC_PORT = "11123"
NC_HOST = "tvsatmaroc.online"
NC_PORT = "11122"
NC_DESKEY = "0102030405060708091011121314"

# ---
# القسم 2: شاشة البلجن الرئيسية
# ---

class TVSATMAROCScreen(Screen):
    # تعريف رقم الإصدار ومسار ملف التحديث
    CURRENT_VERSION = "1.81"
    VERSION_URL = "https://raw.githubusercontent.com/sky-info1/tvsatmaroc/main/version.txt"
    INSTALLER_URL = "https://raw.githubusercontent.com/sky-info1/tvsatmaroc/main/installer.sh"

    skin = """
    <screen name="TVSATMAROC" position="center,center" size="800,600" title="TVSAT MAROC V1.81 DEVELOPED BY YOUNESS">

        <widget name="username_label" position="50,100" size="200,40" font="Regular;22" halign="left" valign="center" foregroundColor="#FFD700" transparent="1" />
        <widget name="username_value" position="260,100" size="490,40" font="Regular;22" halign="left" valign="center" transparent="1" />

        <widget name="password_label" position="50,160" size="200,40" font="Regular;22" halign="left" valign="center" foregroundColor="#FFD700" transparent="1" />
        <widget name="password_value" position="260,160" size="490,40" font="Regular;22" halign="left" valign="center" transparent="1" />

        <widget name="protocol_label" position="50,220" size="200,40" font="Regular;22" halign="left" valign="center" foregroundColor="#FFD700" transparent="1" />
        <widget name="protocol_value" position="260,220" size="490,40" font="Regular;22" halign="left" valign="center" transparent="1" />

        <widget name="destination_label" position="50,280" size="200,40" font="Regular;22" halign="left" valign="center" foregroundColor="#FFD700" transparent="1" />
        <widget name="destination_value" position="260,280" size="490,40" font="Regular;22" halign="left" valign="center" transparent="1" />

        <widget name="update_button_label" position="50,320" size="700,40" font="Regular;22" halign="center" valign="center" transparent="1" />

        <widget name="status_label" position="10,360" size="780,30" font="Regular;22" halign="center" valign="center" transparent="1" />
        
        <widget name="version_label" position="10,400" size="780,30" font="Regular;22" halign="center" valign="center" transparent="1" />
        <widget name="update_status_label" position="10,430" size="780,30" font="Regular;22" halign="center" valign="center" transparent="1" />

        <ePixmap pixmap="skin_default/buttons/yellow.png" position="90,490" size="140,40" alphatest="on" />
        <ePixmap pixmap="skin_default/buttons/blue.png" position="250,490" size="140,40" alphatest="on" />
        <ePixmap pixmap="skin_default/buttons/red.png" position="410,490" size="140,40" alphatest="on" />
        <ePixmap pixmap="skin_default/buttons/green.png" position="570,490" size="140,40" alphatest="on" />
        
        <widget name="key_yellow" position="90,490" zPosition="1" size="140,40" font="Regular;18" halign="center" valign="center" backgroundColor="#a08500" transparent="1" text="Restart" />
        <widget name="key_blue" position="250,490" zPosition="1" size="140,40" font="Regular;18" halign="center" valign="center" backgroundColor="#000080" transparent="1" text="Clear" />
        <widget name="key_red" position="410,490" zPosition="1" size="140,40" font="Regular;18" halign="center" valign="center" backgroundColor="#9f1313" transparent="1" text="Delete" />
        <widget name="key_green" position="570,490" zPosition="1" size="140,40" font="Regular;18" halign="center" valign="center" backgroundColor="#1f771f" transparent="1" text="Save" />

        <widget name="contact_info_label" position="0,540" size="800,60" font="Regular;20" halign="center" valign="center" transparent="1" />
    </screen>"""

    def __init__(self, session):
        Screen.__init__(self, session)
        self.session = session
        
        self.temp_username = config.plugins.TVSATMAROC.username.value
        self.temp_password = config.plugins.TVSATMAROC.password.value

        self["key_red"] = Label("Delete")
        self["key_green"] = Label("Save")
        self["key_yellow"] = Label("Restart")
        self["key_blue"] = Label("Clear")
        self["status_label"] = Label("")
        
        self["contact_info_label"] = Label(
            "For subscription please contact us via WhatsApp or phone:\n+212648374758"
        )
        
        self["username_label"] = Label("Username:")
        self["password_label"] = Label("Password:")
        self["protocol_label"] = Label("Protocol:")
        self["destination_label"] = Label("Destination:")
        
        self["username_value"] = Label(self.temp_username)
        self["password_value"] = Label(self.temp_password)
        self["protocol_value"] = Label(config.plugins.TVSATMAROC.protocol.value)
        self["destination_value"] = Label(config.plugins.TVSATMAROC.destination.value)

        self["version_label"] = Label("Current Version: %s" % self.CURRENT_VERSION)
        self["update_status_label"] = Label("")
        
        self["update_button_label"] = Label("Check for Updates")

        self["actions"] = ActionMap(
            [
                "OkCancelActions",
                "ColorActions",
                "DirectionActions",
                "MenuActions",
                "NumberActions",
                "EPGAction",
            ],
            {
                "ok": self.keyOk,
                "cancel": self.close,
                "green": self.saveConfig,
                "red": self.keyRed, 
                "yellow": self.restartSoftcam,
                "blue": self.clearSelectedField,
                "up": self.keyUp,
                "down": self.keyDown,
                "left": self.keyLeft,
                "right": self.keyRight,
                "0": lambda: self.keyNumber("0"),
                "1": lambda: self.keyNumber("1"),
                "2": lambda: self.keyNumber("2"),
                "3": lambda: self.keyNumber("3"),
                "4": lambda: self.keyNumber("4"),
                "5": lambda: self.keyNumber("5"),
                "6": lambda: self.keyNumber("6"),
                "7": lambda: self.keyNumber("7"),
                "8": lambda: self.keyNumber("8"),
                "9": lambda: self.keyNumber("9"),
                "epg": self.keyBackspace,
            },
            -1,
        )
        
        self.config_items = ["username", "password", "protocol", "destination", "update_button"]
        self.current_focus_index = 0
        self.onLayoutFinish.append(self.updateFocus)

        self.flickerTimer = eTimer()
        self.flickerTimer.callback.append(self.flickerEffect)
        self.flicker_on = False

    def updateFocus(self):
        gold_color = gRGB(0xFFD700)
        yellow_color = gRGB(0xFFFFFF00)
        
        self.flickerTimer.stop()
        self.flicker_on = False
        
        for item_name in self.config_items:
            if item_name == "update_button":
                label_widget = self["update_button_label"]
                if label_widget and label_widget.instance:
                    label_widget.instance.setForegroundColor(gold_color)
            else:
                label_widget = self["{}_label".format(item_name)]
                value_widget = self["{}_value".format(item_name)]
                if label_widget and label_widget.instance:
                    label_widget.instance.setForegroundColor(gold_color)
                if value_widget and value_widget.instance:
                    value_widget.instance.setForegroundColor(gold_color)

        current_item = self.config_items[self.current_focus_index]
        if current_item == "update_button":
            label_widget = self["update_button_label"]
            if label_widget and label_widget.instance:
                label_widget.instance.setForegroundColor(yellow_color)
        else:
            label_widget = self["{}_label".format(current_item)]
            value_widget = self["{}_value".format(current_item)]
            if label_widget and label_widget.instance:
                label_widget.instance.setForegroundColor(yellow_color)
            if value_widget and value_widget.instance:
                value_widget.instance.setForegroundColor(yellow_color)
            
        self.flickerTimer.start(250, True)

    def flickerEffect(self):
        gold_color = gRGB(0xFFD700)
        yellow_color = gRGB(0xFFFFFF00)
        
        self.flicker_on = not self.flicker_on
        
        current_item = self.config_items[self.current_focus_index]
        
        if current_item == "update_button":
            label_widget = self["update_button_label"]
            if self.flicker_on:
                if label_widget and label_widget.instance:
                    label_widget.instance.setForegroundColor(gold_color)
            else:
                if label_widget and label_widget.instance:
                    label_widget.instance.setForegroundColor(yellow_color)
        else:
            label_widget = self["{}_label".format(current_item)]
            value_widget = self["{}_value".format(current_item)]
            if self.flicker_on:
                if label_widget and label_widget.instance:
                    label_widget.instance.setForegroundColor(gold_color)
                if value_widget and value_widget.instance:
                    value_widget.instance.setForegroundColor(gold_color)
            else:
                if label_widget and label_widget.instance:
                    label_widget.instance.setForegroundColor(yellow_color)
                if value_widget and value_widget.instance:
                    value_widget.instance.setForegroundColor(yellow_color)

        self.flickerTimer.start(250, True)

    def keyUp(self):
        if self.current_focus_index > 0:
            self.current_focus_index -= 1
            self.updateFocus()

    def keyDown(self):
        if self.current_focus_index < len(self.config_items) - 1:
            self.current_focus_index += 1
            self.updateFocus()
            
    def keyLeft(self):
        current_item = self.config_items[self.current_focus_index]
        if current_item == "protocol":
            config.plugins.TVSATMAROC.protocol.handleKey(0, 5)
            self["protocol_value"].setText(config.plugins.TVSATMAROC.protocol.value)
        elif current_item == "destination":
            config.plugins.TVSATMAROC.destination.handleKey(0, 5)
            self["destination_value"].setText(config.plugins.TVSATMAROC.destination.value)

    def keyRight(self):
        current_item = self.config_items[self.current_focus_index]
        if current_item == "protocol":
            config.plugins.TVSATMAROC.protocol.handleKey(0, 6)
            self["protocol_value"].setText(config.plugins.TVSATMAROC.protocol.value)
        elif current_item == "destination":
            config.plugins.TVSATMAROC.destination.handleKey(0, 6)
            self["destination_value"].setText(config.plugins.TVSATMAROC.destination.value)

    def keyNumber(self, number):
        current_item = self.config_items[self.current_focus_index]
        if current_item == "username":
            self.temp_username += number
            self.update_value_label(current_item, self.temp_username)
        elif current_item == "password":
            self.temp_password += number
            self.update_value_label(current_item, self.temp_password)
    
    def keyRed(self):
        self.keyBackspace()
    
    def keyBackspace(self):
        current_item = self.config_items[self.current_focus_index]
        if current_item == "username" and len(self.temp_username) > 0:
            self.temp_username = self.temp_username[:-1]
            self.update_value_label(current_item, self.temp_username)
        elif current_item == "password" and len(self.temp_password) > 0:
            self.temp_password = self.temp_password[:-1]
            self.update_value_label(current_item, self.temp_password)

    def update_value_label(self, item_name, value):
        if item_name == "username":
            self["username_value"].setText(value)
        elif item_name == "password":
            self["password_value"].setText(value)

    def keyOk(self):
        current_item = self.config_items[self.current_focus_index]
        if current_item in ["protocol", "destination"]:
            self.keyRight()
        elif current_item == "update_button":
            self.checkForUpdates()

    def saveConfig(self):
        config.plugins.TVSATMAROC.username.value = self.temp_username
        config.plugins.TVSATMAROC.password.value = self.temp_password

        for item in self.config_items:
            if item not in ["update_button"]:
                getattr(config.plugins.TVSATMAROC, item).save()

        username = config.plugins.TVSATMAROC.username.value
        password = config.plugins.TVSATMAROC.password.value
        protocol = config.plugins.TVSATMAROC.protocol.value
        destination = config.plugins.TVSATMAROC.destination.value
        
        file_path = ""
        if destination == "oscam":
            file_path = OSCAM_PATH
        elif destination == "ncam":
            file_path = NCAM_PATH

        if not username or not password:
            self.session.open(MessageBox, "Username and Password cannot be empty!", MessageBox.TYPE_INFO)
            return

        reader_number = 1
        group_number = 1
        
        if protocol == "cccam":
            reader_line = self.generate_cccam_reader(username, password, reader_number, group_number)
        else:
            reader_line = self.generate_newcamd_reader(username, password, reader_number, group_number)

        self.add_or_replace_reader(file_path, reader_line, protocol)
        self.session.open(MessageBox, "Configuration saved successfully!\nExisting reader was replaced, if any.\nPlease restart your Softcam to apply changes.", MessageBox.TYPE_INFO, timeout=5)

    def clearSelectedField(self):
        current_item = self.config_items[self.current_focus_index]
        if current_item == "username":
            self.temp_username = ""
            self["username_value"].setText("")
            message = "Username field cleared."
        elif current_item == "password":
            self.temp_password = ""
            self["password_value"].setText("")
            message = "Password field cleared."
        else:
            message = "Cannot clear this field. It is for display only."
            
        self.session.open(MessageBox, message, MessageBox.TYPE_INFO, timeout=3)
        
    def restartSoftcam(self):
        softcam_command = "/etc/init.d/softcam restart"
        try:
            subprocess.run(softcam_command, shell=True, check=True)
            self.session.open(MessageBox, "Softcam restarted successfully!", MessageBox.TYPE_INFO, timeout=3)
        except subprocess.CalledProcessError as e:
            self.session.open(MessageBox, f"Failed to restart softcam: {e}", MessageBox.TYPE_ERROR)
        except FileNotFoundError:
            self.session.open(MessageBox, "Softcam command not found. Please check your system configuration.", MessageBox.TYPE_ERROR)
            
    def close(self):
        self.flickerTimer.stop()
        if self.temp_username != config.plugins.TVSATMAROC.username.value or \
           self.temp_password != config.plugins.TVSATMAROC.password.value:
            self.session.openWithCallback(self.exit_confirm, MessageBox, "Changes not saved. Do you want to exit without saving?", MessageBox.TYPE_YESNO)
        else:
            Screen.close(self)
        
    def exit_confirm(self, result):
        if result:
            Screen.close(self)

    # وظيفة جديدة للتحقق من التحديثات
    def checkForUpdates(self):
        self["update_status_label"].setText("Checking for updates...")
        d = getPage(self.VERSION_URL.encode("utf-8"))
        d.addCallback(self.updateCheckCallback).addErrback(self.updateCheckError)

    def updateCheckCallback(self, data):
        latest_version = data.decode("utf-8").strip()
        if latest_version > self.CURRENT_VERSION:
            message = f"New version {latest_version} is available. Do you want to update now?"
            self.session.openWithCallback(self.update_confirmation_callback, MessageBox, message, MessageBox.TYPE_YESNO)
        else:
            self["update_status_label"].setText("No updates available.")

    def update_confirmation_callback(self, result):
        if result:
            self.performUpdate()
        else:
            self["update_status_label"].setText("Update cancelled by user.")

    def updateCheckError(self, error):
        self["update_status_label"].setText("Update check failed. Check your network connection.")

    # وظيفة جديدة لتنفيذ التحديث
    def performUpdate(self):
        self["update_status_label"].setText("Downloading and installing update...")
        # تنزيل سكربت التثبيت أولاً
        d = getPage(self.INSTALLER_URL.encode("utf-8"))
        d.addCallback(self.downloadInstallerCallback).addErrback(self.downloadInstallerError)

    def downloadInstallerCallback(self, data):
        try:
            with open(INSTALLER_PATH, "wb") as f:
                f.write(data)
            os.chmod(INSTALLER_PATH, 0o755) # جعل السكربت قابلاً للتنفيذ
            self.executeInstaller()
        except Exception as e:
            self.session.open(MessageBox, f"Failed to save installer script: {e}", MessageBox.TYPE_ERROR)

    def downloadInstallerError(self, error):
        self.session.open(MessageBox, "Failed to download installer script. Check your internet connection.", MessageBox.TYPE_ERROR)

    def executeInstaller(self):
        self["update_status_label"].setText("Installing update, please wait...")
        try:
            # تشغيل سكربت التثبيت
            process = subprocess.run([INSTALLER_PATH], check=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True)
            self.session.open(MessageBox, "Update successful! Please reboot your receiver to complete the process.", MessageBox.TYPE_INFO)
            self["update_status_label"].setText("Update finished. Reboot to apply.")
        except subprocess.CalledProcessError as e:
            self.session.open(MessageBox, f"Update failed! Error: {e.stderr}", MessageBox.TYPE_ERROR)
        except FileNotFoundError:
            self.session.open(MessageBox, "Installer script not found.", MessageBox.TYPE_ERROR)
        except Exception as e:
            self.session.open(MessageBox, f"An unexpected error occurred during update: {e}", MessageBox.TYPE_ERROR)

    # ---
    # Helper functions
    # ---
    
    def add_or_replace_reader(self, file_path, new_reader, protocol):
        """
        Reads the file, replaces an existing reader block, or appends a new one.
        """
        prefix = "tvsatmaroc_C" if protocol == "cccam" else "tvsatmaroc_N"
        reader_label_to_find = f"label = {prefix}1"
        reader_block_start = "[reader]"

        try:
            with open(file_path, 'r') as f:
                content = f.read()
        except FileNotFoundError:
            with open(file_path, 'w') as f:
                f.write(new_reader)
            return

        regex = r'(\[reader\].*?label\s*=\s*' + prefix + r'1.*?)(?=\[reader\]|\Z)'
        match = re.search(regex, content, re.DOTALL | re.IGNORECASE)

        if match:
            old_reader_block = match.group(1)
            content = content.replace(old_reader_block, new_reader)
        else:
            content += new_reader

        with open(file_path, 'w') as f:
            f.write(content)

    def generate_cccam_reader(self, username, password, reader_number, group_number):
        reader_label = f"tvsatmaroc_C{reader_number}"
        return f"""
[reader]
label = {reader_label}
enable = 1
protocol = cccam
device = {CC_HOST},{CC_PORT}
user = {username}
password = {password}
inactivitytimeout = 30
group = {group_number}
cccversion = 2.1.3
cccmaxhop = 1

"""

    def generate_newcamd_reader(self, username, password, reader_number, group_number):
        reader_label = f"tvsatmaroc_N{reader_number}"
        return f"""
[reader]
label = {reader_label}
enable = 1
protocol = newcamd 
device = {NC_HOST},{NC_PORT}
user = {username}
password = {password}
deskey = {NC_DESKEY}
inactivitytimeout = 30
group = {group_number}

"""

# ---
# القسم 3: تعريف البلجن
# ---

def main(session, **kwargs):
    session.open(TVSATMAROCScreen)

def Plugins(**kwargs):
    return [
        PluginDescriptor(
            name="TVSATMAROC",
            description="Configure your CCCam/Newcamd reader and manage softcams",
            where=PluginDescriptor.WHERE_PLUGINMENU,
            fnc=main,
            icon="plugin.png"
        )
    ]