# -*- coding: utf-8 -*-
from __future__ import absolute_import, print_function, unicode_literals
from Plugins.Plugin import PluginDescriptor
from Screens.Screen import Screen
from Components.ActionMap import ActionMap
from Components.Label import Label
from Components.config import config, ConfigSubsection, ConfigText, ConfigSelection
from Screens.MessageBox import MessageBox
import subprocess
import re
import os
from enigma import gRGB

# ---
# القسم 1: تعريف الثوابت والإعدادات
# ---

# تعريف إعدادات البلجن
config.plugins.TVSATMAROC = ConfigSubsection()
config.plugins.TVSATMAROC.username = ConfigText(default="", fixed_size=False)
config.plugins.TVSATMAROC.password = ConfigText(default="", fixed_size=False)
config.plugins.TVSATMAROC.protocol = ConfigSelection(default="cccam", choices=[("cccam", "CCCam"), ("newcamd", "Newcamd")])
config.plugins.TVSATMAROC.destination = ConfigSelection(default="oscam", choices=[("oscam", "OSCam"), ("ncam", "NCam")])

# تعريف مسارات الملفات ومعلومات السيرفر الثابتة
OSCAM_PATH = "/etc/tuxbox/config/oscam.server"
NCAM_PATH = "/etc/tuxbox/config/ncam.server"

CC_HOST = "tvsatmaroc.online"
CC_PORT = "11123"
NC_HOST = "tvsatmaroc.online"
NC_PORT = "11122"
NC_DESKEY = "0102030405060708091011121314"

# ---
# القسم 2: شاشة البلجن الرئيسية
# ---

class TVSATMAROCScreen(Screen):
    skin = """
    <screen name="TVSATMAROC" position="center,center" size="800,600" title="TVSAT MAROC V1.80 DEVELOPED BY YOUNESS">
        <ePixmap pixmap="skin_default/buttons/red.png" position="255,30" size="140,40" alphatest="on" />
        <ePixmap pixmap="skin_default/buttons/green.png" position="405,30" size="140,40" alphatest="on" />
        <widget name="key_red" position="255,30" zPosition="1" size="140,40" font="Regular;20" halign="center" valign="center" backgroundColor="#9f1313" transparent="1" text="Delete" />
        <widget name="key_green" position="405,30" zPosition="1" size="140,40" font="Regular;20" halign="center" valign="center" backgroundColor="#1f771f" transparent="1" text="Save" />
        
        <widget name="username_label" position="50,100" size="200,40" font="Regular;22" halign="left" valign="center" />
        <widget name="username_value" position="260,100" size="490,40" font="Regular;22" halign="left" valign="center" />

        <widget name="password_label" position="50,160" size="200,40" font="Regular;22" halign="left" valign="center" />
        <widget name="password_value" position="260,160" size="490,40" font="Regular;22" halign="left" valign="center" />

        <widget name="protocol_label" position="50,220" size="200,40" font="Regular;22" halign="left" valign="center" />
        <widget name="protocol_value" position="260,220" size="490,40" font="Regular;22" halign="left" valign="center" />

        <widget name="destination_label" position="50,280" size="200,40" font="Regular;22" halign="left" valign="center" />
        <widget name="destination_value" position="260,280" size="490,40" font="Regular;22" halign="left" valign="center" />

        <widget name="status_label" position="10,350" size="780,30" font="Regular;22" halign="center" valign="center" />
        
        <ePixmap pixmap="skin_default/buttons/yellow.png" position="16,400" size="200,50" alphatest="on" />
        <widget name="key_yellow" position="16,400" zPosition="1" size="200,50" font="Regular;18" halign="center" valign="center" backgroundColor="#a08500" transparent="1" text="Restart Softcam" />

        <ePixmap pixmap="skin_default/buttons/blue.png" position="220,400" size="200,50" alphatest="on" />
        <widget name="key_blue" position="220,400" zPosition="1" size="200,50" font="Regular;18" halign="center" valign="center" backgroundColor="#000080" transparent="1" text="Clear" />
        
        <widget name="contact_info_label" position="0,550" size="800,35" font="Regular;26" halign="center" valign="center" transparent="1" />
    </screen>"""

    def __init__(self, session):
        Screen.__init__(self, session)
        self.session = session
        
        # إضافة متغيرات مؤقتة للاسم وكلمة المرور
        self.temp_username = config.plugins.TVSATMAROC.username.value
        self.temp_password = config.plugins.TVSATMAROC.password.value

        self["key_red"] = Label("Delete")
        self["key_green"] = Label("Save")
        self["key_yellow"] = Label("Restart Softcam")
        self["key_blue"] = Label("Clear")
        self["status_label"] = Label("")
        self["contact_info_label"] = Label("For subscription contact us via WhatsApp or phone +212648374758")
        
        self["username_label"] = Label("Username:")
        self["password_label"] = Label("Password:")
        self["protocol_label"] = Label("Protocol:")
        self["destination_label"] = Label("Destination:")
        
        self["username_value"] = Label(self.temp_username)
        self["password_value"] = Label(self.temp_password)
        self["protocol_value"] = Label(config.plugins.TVSATMAROC.protocol.value)
        self["destination_value"] = Label(config.plugins.TVSATMAROC.destination.value)

        self["actions"] = ActionMap(["OkCancelActions", "ColorActions", "DirectionActions", "MenuActions", "NumberActions", "EPGAction"],
        {
            "ok": self.keyOk,
            "cancel": self.close,
            "green": self.saveConfig,
            "red": self.keyRed, 
            "yellow": self.restartSoftcam,
            "blue": self.clearSelectedField,
            "up": self.keyUp,
            "down": self.keyDown,
            "left": self.keyLeft,
            "right": self.keyRight,
            "0": lambda: self.keyNumber("0"),
            "1": lambda: self.keyNumber("1"),
            "2": lambda: self.keyNumber("2"),
            "3": lambda: self.keyNumber("3"),
            "4": lambda: self.keyNumber("4"),
            "5": lambda: self.keyNumber("5"),
            "6": lambda: self.keyNumber("6"),
            "7": lambda: self.keyNumber("7"),
            "8": lambda: self.keyNumber("8"),
            "9": lambda: self.keyNumber("9"),
            "epg": self.keyBackspace,
        }, -1)
        
        self.config_items = ["username", "password", "protocol", "destination"]
        self.current_focus_index = 0
        self.onLayoutFinish.append(self.updateFocus)

    def updateFocus(self):
        yellow_color = gRGB(0xFFFFFF00)
        white_color = gRGB(0xFFFFFFFF)
        for i, item_name in enumerate(self.config_items):
            label_widget = self["{}_label".format(item_name)]
            value_widget = self["{}_value".format(item_name)]
            if i == self.current_focus_index:
                if label_widget and label_widget.instance:
                    label_widget.instance.setForegroundColor(yellow_color)
                if value_widget and value_widget.instance:
                    value_widget.instance.setForegroundColor(yellow_color)
            else:
                if label_widget and label_widget.instance:
                    label_widget.instance.setForegroundColor(white_color)
                if value_widget and value_widget.instance:
                    value_widget.instance.setForegroundColor(white_color)

    def keyUp(self):
        if self.current_focus_index > 0:
            self.current_focus_index -= 1
            self.updateFocus()

    def keyDown(self):
        if self.current_focus_index < len(self.config_items) - 1:
            self.current_focus_index += 1
            self.updateFocus()
            
    def keyLeft(self):
        current_item = self.config_items[self.current_focus_index]
        if current_item == "protocol":
            config.plugins.TVSATMAROC.protocol.handleKey(0, 5)
            self["protocol_value"].setText(config.plugins.TVSATMAROC.protocol.value)
        elif current_item == "destination":
            config.plugins.TVSATMAROC.destination.handleKey(0, 5)
            self["destination_value"].setText(config.plugins.TVSATMAROC.destination.value)

    def keyRight(self):
        current_item = self.config_items[self.current_focus_index]
        if current_item == "protocol":
            config.plugins.TVSATMAROC.protocol.handleKey(0, 6)
            self["protocol_value"].setText(config.plugins.TVSATMAROC.protocol.value)
        elif current_item == "destination":
            config.plugins.TVSATMAROC.destination.handleKey(0, 6)
            self["destination_value"].setText(config.plugins.TVSATMAROC.destination.value)

    def keyNumber(self, number):
        current_item = self.config_items[self.current_focus_index]
        if current_item == "username":
            self.temp_username += number
            self.update_value_label("username", self.temp_username)
        elif current_item == "password":
            self.temp_password += number
            self.update_value_label("password", self.temp_password)
    
    def keyRed(self):
        self.keyBackspace()
    
    def keyBackspace(self):
        current_item = self.config_items[self.current_focus_index]
        if current_item == "username":
            self.temp_username = self.temp_username[:-1]
            self.update_value_label("username", self.temp_username)
        elif current_item == "password":
            self.temp_password = self.temp_password[:-1]
            self.update_value_label("password", self.temp_password)

    def update_value_label(self, item_name, value):
        if item_name == "username":
            self["username_value"].setText(value)
        elif item_name == "password":
            self["password_value"].setText(value)

    def keyOk(self):
        current_item = self.config_items[self.current_focus_index]
        if current_item in ["protocol", "destination"]:
            self.keyRight()

    def saveConfig(self):
        # حفظ المتغيرات المؤقتة إلى إعدادات البلجن
        config.plugins.TVSATMAROC.username.value = self.temp_username
        config.plugins.TVSATMAROC.password.value = self.temp_password
        
        for item in self.config_items:
            getattr(config.plugins.TVSATMAROC, item).save()

        username = config.plugins.TVSATMAROC.username.value
        password = config.plugins.TVSATMAROC.password.value
        protocol = config.plugins.TVSATMAROC.protocol.value
        destination = config.plugins.TVSATMAROC.destination.value
        
        file_path = ""
        if destination == "oscam":
            file_path = OSCAM_PATH
        elif destination == "ncam":
            file_path = NCAM_PATH

        if not username or not password:
            self.session.open(MessageBox, "Username and Password cannot be empty!", MessageBox.TYPE_INFO)
            return

        reader_number = self.get_next_reader_number(file_path, protocol)
        group_number = self.find_next_group(file_path)

        if protocol == "cccam":
            reader_line = self.generate_cccam_reader(username, password, reader_number, group_number)
        else:
            reader_line = self.generate_newcamd_reader(username, password, reader_number, group_number)

        self.append_to_file(file_path, reader_line)
        self.session.open(MessageBox, "Configuration saved successfully!\nPlease restart your Softcam to apply changes.", MessageBox.TYPE_INFO, timeout=5)

    def clearSelectedField(self):
        current_item = self.config_items[self.current_focus_index]
        if current_item == "username":
            self.temp_username = ""
            self["username_value"].setText("")
            message = "Username field cleared."
        elif current_item == "password":
            self.temp_password = ""
            self["password_value"].setText("")
            message = "Password field cleared."
        else:
            message = "Cannot clear this field. It is for display only."
            
        self.session.open(MessageBox, message, MessageBox.TYPE_INFO, timeout=3)
        
    def restartSoftcam(self):
        softcam_command = "/etc/init.d/softcam restart"
        try:
            subprocess.run(softcam_command, shell=True, check=True)
            self.session.open(MessageBox, "Softcam restarted successfully!", MessageBox.TYPE_INFO, timeout=3)
        except subprocess.CalledProcessError as e:
            self.session.open(MessageBox, f"Failed to restart softcam: {e}", MessageBox.TYPE_ERROR)
        except FileNotFoundError:
            self.session.open(MessageBox, "Softcam command not found. Please check your system configuration.", MessageBox.TYPE_ERROR)
            
    def close(self):
        # عند الخروج، يمكن سؤال المستخدم عما إذا كان يريد تجاهل التغييرات
        if self.temp_username != config.plugins.TVSATMAROC.username.value or \
           self.temp_password != config.plugins.TVSATMAROC.password.value:
            self.session.openWithCallback(self.exit_confirm, MessageBox, "Changes not saved. Do you want to exit without saving?", MessageBox.TYPE_YESNO)
        else:
            Screen.close(self)

    def exit_confirm(self, result):
        if result:
            Screen.close(self)

    # ---
    # Helper functions (No changes here)
    # ---
    def get_next_reader_number(self, file_path, protocol):
        prefix = "tvsatmaroc_C" if protocol == "cccam" else "tvsatmaroc_N"
        last_number = 0
        try:
            with open(file_path, 'r') as f:
                content = f.read()
                matches = re.findall(r'label\s*=\s*' + prefix + r'(\d+)', content)
                if matches:
                    last_number = max([int(n) for n in matches])
        except FileNotFoundError:
            pass
        return last_number + 1

    def find_next_group(self, file_path):
        used_groups = set()
        try:
            with open(file_path, 'r') as f:
                content = f.read()
                groups = re.findall(r'group\s*=\s*(\d+)', content)
                used_groups.update([int(g) for g in groups])
        except FileNotFoundError:
            pass
            
        for i in range(1, 11):
            if i not in used_groups:
                return i
        return 1

    def append_to_file(self, file_path, content_to_add):
        try:
            with open(file_path, 'a') as f:
                f.write(content_to_add)
        except Exception as e:
            self.session.open(MessageBox, f"Error writing to file: {e}", MessageBox.TYPE_ERROR)

    def generate_cccam_reader(self, username, password, reader_number, group_number):
        reader_label = f"tvsatmaroc_C{reader_number}"
        return f"""
[reader]
label = {reader_label}
enable = 1
protocol = cccam
device = {CC_HOST},{CC_PORT}
user = {username}
password = {password}
inactivitytimeout = 30
group = {group_number}
cccversion = 2.1.3
cccmaxhop = 1

"""

    def generate_newcamd_reader(self, username, password, reader_number, group_number):
        reader_label = f"tvsatmaroc_N{reader_number}"
        return f"""
[reader]
label = {reader_label}
enable = 1
protocol = newcamd 
device = {NC_HOST},{NC_PORT}
user = {username}
password = {password}
deskey = {NC_DESKEY}
inactivitytimeout = 30
group = {group_number}

"""

# ---
# القسم 3: تعريف البلجن
# ---

def main(session, **kwargs):
    session.open(TVSATMAROCScreen)

def Plugins(**kwargs):
    return [
        PluginDescriptor(
            name="TVSATMAROC",
            description="Configure your CCCam/Newcamd reader and manage softcams",
            where=PluginDescriptor.WHERE_PLUGINMENU,
            fnc=main,
            icon="plugin.png"
        )
    ]