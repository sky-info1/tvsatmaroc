from Plugins.Plugin import PluginDescriptor
from Screens.Screen import Screen
from Screens.MessageBox import MessageBox
from Components.ActionMap import ActionMap
from Components.ConfigList import ConfigListScreen, ConfigList
from Components.config import config, ConfigSubsection, ConfigText, ConfigSelection, getConfigListEntry
from Components.Label import Label
import os
from enigma import eTimer

# تعريف قسم الإعدادات للبلجن
config.plugins.TVSATMAROC = ConfigSubsection()
config.plugins.TVSATMAROC.username = ConfigText(default="", fixed_size=False)
config.plugins.TVSATMAROC.password = ConfigText(default="", fixed_size=False)
config.plugins.TVSATMAROC.protocol = ConfigSelection(default="cccam", choices=[("cccam", "CCCam"), ("newcamd", "Newcamd")])
config.plugins.TVSATMAROC.destination = ConfigSelection(default="oscam", choices=[("oscam", "OSCam"), ("ncam", "NCam")])

class TVSATMAROCScreen(Screen, ConfigListScreen):
    # حجم الشاشة يبقى 800,600
    skin = """
    <screen name="TVSATMAROC" position="center,center" size="800,600" title="TVSAT MAROC V1.65 DEVELOPED BY YOUNESS">
        <ePixmap pixmap="skin_default/buttons/red.png" position="255,30" size="140,40" alphatest="on" />
        <ePixmap pixmap="skin_default/buttons/green.png" position="405,30" size="140,40" alphatest="on" />
        <widget name="key_red" position="255,30" zPosition="1" size="140,40" font="Regular;20" halign="center" valign="center" backgroundColor="#9f1313" transparent="1" text="Cancel" />
        <widget name="key_green" position="405,30" zPosition="1" size="140,40" font="Regular;20" halign="center" valign="center" backgroundColor="#1f771f" transparent="1" text="Save" />
        
        <widget name="config" position="50,90" size="700,300" scrollbarMode="showOnDemand" font="Regular;32" itemHeight="50" />

        <widget name="status_label" position="10,435" size="780,30" font="Regular;22" halign="center" valign="center" />
        
        <ePixmap pixmap="skin_default/buttons/yellow.png" position="16,470" size="180,50" alphatest="on" />
        <widget name="key_yellow" position="16,470" zPosition="1" size="180,50" font="Regular;18" halign="center" valign="center" backgroundColor="#a08500" transparent="1" text="Restart OSCam" />

        <ePixmap pixmap="skin_default/buttons/blue.png" position="212,470" size="180,50" alphatest="on" />
        <widget name="key_blue" position="212,470" zPosition="1" size="180,50" font="Regular;18" halign="center" valign="center" backgroundColor="#000080" transparent="1" text="Restart NCam" />

        <ePixmap pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TVSATMAROC/clear_icon.png" position="408,470" size="180,50" alphatest="on" />
        <widget name="key_clear_all" position="408,470" zPosition="1" size="180,50" font="Regular;18" halign="center" valign="center" transparent="1" text="Clear All (Menu)" />

        <ePixmap pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TVSATMAROC/backspace_icon.png" position="604,470" size="180,50" alphatest="on" />
        <widget name="key_backspace_selected" position="604,470" zPosition="1" size="180,50" font="Regular;18" halign="center" valign="center" transparent="1" text="Backspace (EPG)" />

        <widget name="contact_info_label" position="10,550" size="780,35" font="Regular;26" halign="center" valign="center" transparent="1" /> 
    </screen>"""

    def __init__(self, session):
        Screen.__init__(self, session)
        self.session = session
        self.list = []
        ConfigListScreen.__init__(self, self.list, session=self.session)

        # Labels for buttons
        self["key_red"] = Label(_("Cancel"))
        self["key_green"] = Label(_("Save"))
        self["key_yellow"] = Label(_("Restart OSCam"))
        self["key_blue"] = Label(_("Restart NCam"))
        self["key_clear_all"] = Label(_("Clear All (Menu)"))
        self["key_backspace_selected"] = Label(_("Backspace (EPG)"))
        
        # Status Label
        self["status_label"] = Label("")
        
        # Bottom label: Contact Info - TEXT UPDATED AND FONT SIZE NOW 26
        self["contact_info_label"] = Label(_("للاشتراك المرجوا التواصل معنا عبر الواتس اب او رقم الهاتف على الرقم التالي 0648374758"))

        self["actions"] = ActionMap(["OkCancelActions", "ColorActions", "GlobalActions", "NumberActions", "MenuActions", "EPGSelectActions"],
        {
            "ok": self.saveConfig,
            "cancel": self.close,
            "green": self.saveConfig,
            "red": self.close,
            "yellow": self.restartOscam,
            "blue": self.restartNcam,
            "menu": self.clearAllFields,
            "epg": self.backspaceSelectedField,
        }, -1)
        
        self.onShown.append(self.updateTitle)
        self.createConfigList()
    
    def updateTitle(self):
        # تحديث عنوان الشاشة ليظهر الاسم الجديد
        self.setTitle(_("TVSAT MAROC V1.65 DEVELOPED BY YOUNESS"))

    def createConfigList(self):
        self.list = [
            getConfigListEntry(_("Username"), config.plugins.TVSATMAROC.username),
            getConfigListEntry(_("Password"), config.plugins.TVSATMAROC.password),
            getConfigListEntry(_("Protocol"), config.plugins.TVSATMAROC.protocol),
            getConfigListEntry(_("Destination"), config.plugins.TVSATMAROC.destination),
        ]
        self["config"].setList(self.list)

    def saveConfig(self):
        for x in self["config"].list:
            x[1].save()

        username = config.plugins.TVSATMAROC.username.value
        password = config.plugins.TVSATMAROC.password.value
        protocol = config.plugins.TVSATMAROC.protocol.value
        destination = config.plugins.TVSATMAROC.destination.value

        if not username or not password:
            self.session.open(MessageBox, _("Username and Password cannot be empty!"), type=MessageBox.TYPE_ERROR)
            return

        if destination == "oscam":
            config_dir = "/etc/tuxbox/config"
            if not os.path.exists(config_dir):
                os.makedirs(config_dir)
            path = os.path.join(config_dir, "oscam.server")
        else: # ncam
            config_dir = "/etc/tuxbox/config/ncam"
            if not os.path.exists(config_dir):
                os.makedirs(config_dir, exist_ok=True)
            path = os.path.join(config_dir, "ncam.server")

        if protocol == "cccam":
            config_content = (
                "[reader]\n"
                "label = tvsatmaroc\n"
                "enable = 1\n"
                "protocol = cccam\n"
                "device = tvsatmaroc.online,11123\n"
                "user = %s\n"
                "password = %s\n"
                "group = 1\n"
                "cccversion = 2.3.0\n"
            ) % (username, password)
        else: # newcamd
            config_content = (
                "[reader]\n"
                "label = tvsatmaroc\n"
                "enable = 1\n"
                "protocol = newcamd\n"
                "device = tvsatmaroc.online,11122\n"
                "user = %s\n"
                "password = %s\n"
                "key = 0102030405060708091011121314\n"
                "group = 1\n"
            ) % (username, password)

        try:
            with open(path, "w") as f:
                f.write(config_content)
            self.session.open(MessageBox, _("Reader [tvsatmaroc] saved to:\n%s") % path, type=MessageBox.TYPE_INFO)
        except IOError as e:
            self.session.open(MessageBox, _("Error writing to file:\n%s") % str(e), type=MessageBox.TYPE_ERROR)

    def restartOscam(self):
        command = "/etc/init.d/softcam.oscam restart"
        self["status_label"].setText(_("Restarting OSCam..."))
        os.system(command)
        self.timer = eTimer()
        self.timer.callback.append(self.updateStatusAfterRestart)
        self.timer.start(3000, True)

    def restartNcam(self):
        command = "/etc/init.d/softcam.ncam restart"
        self["status_label"].setText(_("Restarting NCam..."))
        os.system(command)
        self.timer = eTimer()
        self.timer.callback.append(self.updateStatusAfterRestart)
        self.timer.start(3000, True)

    def updateStatusAfterRestart(self):
        self["status_label"].setText(_("Restart command sent. Check softcam status manually."))

    def clearAllFields(self):
        print("[TVSATMAROC] clearAllFields function called!")
        config.plugins.TVSATMAROC.username.value = ""
        config.plugins.TVSATMAROC.password.value = ""
        self.createConfigList()

    def backspaceSelectedField(self):
        print("[TVSATMAROC] backspaceSelectedField function called!")
        current_selection = self["config"].getCurrent()
        
        if current_selection and isinstance(current_selection[1], ConfigText):
            if current_selection[1] is config.plugins.TVSATMAROC.username or \
               current_selection[1] is config.plugins.TVSATMAROC.password:
                
                current_text = current_selection[1].value
                if current_text:
                    current_selection[1].value = current_text[:-1]
                    self.createConfigList()

def main(session, **kwargs):
    session.open(TVSATMAROCScreen)

def Plugins(**kwargs):
    return [PluginDescriptor(
        # هذا هو الاسم الذي سيظهر في قائمة البلاجن على جهازك
        name="TVSATMAROC", 
        description="Configure your CCCam/Newcamd reader and manage softcams",
        where = PluginDescriptor.WHERE_PLUGINMENU,
        icon="plugin.png",
        fnc=main
    )]